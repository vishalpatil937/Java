package com.xoriant.beans;

public enum Units {
	kg, gallon,grams,nos;
}
