package com.xoriant.client;

public class Client {

	public static void main(String[] args) {

	}

}
