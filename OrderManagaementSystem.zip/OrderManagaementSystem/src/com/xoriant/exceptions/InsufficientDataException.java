package com.xoriant.exceptions;

public class InsufficientDataException extends Exception {
	
}
